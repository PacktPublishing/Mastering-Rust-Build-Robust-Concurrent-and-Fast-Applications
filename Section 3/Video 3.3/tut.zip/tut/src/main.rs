mod conversation;


fn main() {
    println!("Program works!");
	conversation::hello::hi();
	conversation::goodbye::bye();
}
