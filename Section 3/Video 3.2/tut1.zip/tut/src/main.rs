mod conversation{
	mod hello{
		fn hi(){
			println!("hi!");
		}
	}
	mod goodbye{
		fn bye(){
			println!("bye!");
		}
	}
}


fn main() {
    println!("Program works!");
}
