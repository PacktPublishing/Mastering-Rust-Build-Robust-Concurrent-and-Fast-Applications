mod hello{
		fn hi(){
			println!("hi!");
		}
	}
	mod goodbye{
		fn bye(){
			println!("bye!");
		}
	}
