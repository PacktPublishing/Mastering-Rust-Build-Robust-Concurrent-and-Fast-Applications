mod comparison;
mod addition;

use addition::add as a;
use comparison::compare as c;

fn main(){
	let x = 5;
	let z = 7;
	let y = 9;
	c(a(x,y),a(x,z));
}