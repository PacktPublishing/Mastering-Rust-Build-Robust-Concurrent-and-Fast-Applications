fn main() {
    println!("Program works!");
}
