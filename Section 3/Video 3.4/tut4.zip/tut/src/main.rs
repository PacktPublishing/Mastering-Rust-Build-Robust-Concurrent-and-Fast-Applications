mod conversation;

use conversation::*;

fn main() {
    println!("Program works!");
	hello::hi();
	goodbye::bye();
}
