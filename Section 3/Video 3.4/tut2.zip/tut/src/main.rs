mod conversation;

use conversation::{hello, goodbye};

fn main() {
    println!("Program works!");
	hello::hi();
	goodbye::bye();
}
