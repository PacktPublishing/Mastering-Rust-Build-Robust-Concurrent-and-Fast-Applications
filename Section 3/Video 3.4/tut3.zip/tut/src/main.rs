mod conversation;

use conversation::hello as h;
use conversation::goodbye as g;

fn main() {
    println!("Program works!");
	h::hi();
	g::bye();
}
