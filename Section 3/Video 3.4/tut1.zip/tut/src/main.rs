mod conversation;

use conversation::hello;
use conversation::goodbye;

fn main() {
    println!("Program works!");
	hello::hi();
	goodbye::bye();
}
